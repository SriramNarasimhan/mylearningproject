package com.searchandreplace.constants;

/**
 * @author 
 */

public final class SRConstant {

/**
* Constants.
*/

/**
* HTTP.
*/
public static final String HTTP = "http://";
/**
 * HOST_NAME.
 */
public static final String HOST_NAME = "localhost";
/**
 * COLON
 */
public static final String COLON = ":";
/**
 * PORT_NUMBER
 */
public static final String PORT_NUMBER = "4502";
/**
 * USERNAME
 */
public static final String USERNAME = "admin";
/**
 * PASSWORD
 */
public static final String PASSWORD = "admin";
/**
 * CRX_SERVER
 */
public static final String CRX_SERVER = "/crx/server";
/**
 * SUCCESS
 */
public static final String SUCCESS = "success";
/**
 * FAILED
 */
public static final String FAILED = "failed";


}
