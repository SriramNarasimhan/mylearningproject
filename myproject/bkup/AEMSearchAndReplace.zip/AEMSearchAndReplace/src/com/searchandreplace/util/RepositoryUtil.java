package com.searchandreplace.util;

import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;

import org.apache.jackrabbit.commons.JcrUtils;

import com.searchandreplace.constants.SRConstant;


/**
 * @author 
 * 
 */
public class RepositoryUtil {

	public static Session getConnection(final String ipAddress,
			final String portNumber, final String userName,
			final String password) throws RepositoryException {

		System.out.println("Starting to connect to CQ Repository");

		// Create a connection to the Adobe Day CQ repository running on local
		// host
		Repository repository = JcrUtils.getRepository(SRConstant.HTTP
				+ ipAddress + SRConstant.COLON + portNumber
				+ SRConstant.CRX_SERVER);
		// Create a Session instance
		Session session = repository.login(new SimpleCredentials(userName,
				password.toCharArray()));

		System.out.println("Connected to Repository");
		return session;
	}
}
