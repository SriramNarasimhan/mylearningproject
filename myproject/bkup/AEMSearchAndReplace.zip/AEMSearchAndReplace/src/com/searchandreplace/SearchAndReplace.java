package com.searchandreplace;

import java.io.FileInputStream;
import java.util.Properties;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.searchandreplace.util.RepositoryUtil;

public class SearchAndReplace {
	private static Logger log = LoggerFactory.getLogger(SearchAndReplace.class);

	public static void main(String[] args) {

		System.out.println("Calling method to get connection to CQ Repository");
		log.info("Calling method to get connection to CQ Repository");
		Properties prop = new Properties();
		try {
			// load a properties file
			prop.load(new FileInputStream("src/config.properties"));

			// get the property value and print it out
			String ipAddress = prop.getProperty("IpAddress", "localhost");
			String portNumber = prop.getProperty("port", "4502");
			String userName = prop.getProperty("username", "admin");
			String password = prop.getProperty("password", "admin");

			/*
			 * String templates = prop.getProperty("templates",""); String[] templateNames = templates.split(","); int
			 * tempLen = templateNames.length; String folderLoc = prop.getProperty("folderLocs",""); String[]
			 * folderLocations = folderLoc.split(","); int folderLen = folderLocations.length; String dest_Path =
			 * prop.getProperty("destinationPaths",""); //String lastModifiedDate =
			 * prop.getProperty("lastModifiedDate",""); String[] destinationPaths = dest_Path.split(","); int destLen =
			 * destinationPaths.length;
			 */

			// getting the session
			Session session = RepositoryUtil.getConnection(ipAddress, portNumber, userName, password);

			QueryManager queryManager = session.getWorkspace().getQueryManager();
			log.info("queryManager: " + queryManager.toString());
			// String sqlQuery =
			// "select * from nt:base where jcr:path like '"+storagePath+userNode.getName()+"/jcr:content/%' and contains(*, 'unitconfig*') ORDER BY submitted DESC";
			String sqlQuery = "select * from cq:LiveSyncConfig where jcr:path like '/content/whg-ecomm/rd1/ra/en_us/propertypage/fl/%' and cq:master='/content/whg-ecomm/rd1/ra/en_us/overview'";
			log.info("sqlQuery: " + sqlQuery);
			System.out.println("sqlQuery: " + sqlQuery);
			Query query = queryManager.createQuery(sqlQuery, Query.SQL);
			log.info("query: " + query.toString());
			System.out.println("query: " + query.toString());

			QueryResult result = query.execute();
			log.info("result: " + result.toString());
			
			NodeIterator iterator = result.getNodes();
			System.out.println(iterator.getSize());
			
			/*ResourceResolverFactory resolverFactory;
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			ModifiableValueMap map = resource.adaptTo(ModifiableValueMap.class);
			map.put("property", "value");
			resource.getResourceResolver().commit();*/

			if (null != session) {
				session.logout();
			}


		} catch (RepositoryException repositoryException) {
			System.out.println(repositoryException.getMessage());
			log.info("repositoryException.getMessage()= " + repositoryException.getMessage());
			repositoryException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Exception is : " + e.getMessage());
			log.info("Exception is : " + e.getMessage());
			e.printStackTrace();
		}

	}

}
